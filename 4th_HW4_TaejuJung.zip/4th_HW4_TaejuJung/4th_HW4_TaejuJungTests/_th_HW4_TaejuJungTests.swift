//
//  _th_HW4_TaejuJungTests.swift
//  4th_HW4_TaejuJungTests
//
//  Created by 정태주 on 4/8/25.
//

import Testing
@testable import _th_HW4_TaejuJung

struct _th_HW4_TaejuJungTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
