//
//  _th_HW4_TaejuJungApp.swift
//  4th_HW4_TaejuJung
//
//  Created by 정태주 on 4/8/25.
//

import SwiftUI

@main
struct _th_HW4_TaejuJungApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
